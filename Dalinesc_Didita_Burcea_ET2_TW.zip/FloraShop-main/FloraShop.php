<html>
    <head>
        <link href="https://fonts.googleapis.com/css?family=Economica" rel="stylesheet">
          <link rel="stylesheet" href="C:\Users\User\OneDrive\Desktop\MyFold2\Anul 3 Info\Tehnologii Web\FloraShop\css-FloraShop.css"/>
          <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>
          <script src='https://cdnjs.cloudflare.com/ajax/libs/simplecartjs/3.0.5/simplecart.min.js'></script>
          <link rel="preconnect" href="https://fonts.googleapis.com">
          <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
          <link href="https://fonts.googleapis.com/css2?family=Petemoss&display=swap" rel="stylesheet"> 
    
        </head>
    <body>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" >
        <nav>
          <ul>
            <li id='logo' style=" font-family:Petemoss; font-size:100px;" >FloraShop</li>
            <li class = 'nav-style' ><a href='https://s.codepen.io/vperr007/debug/oWNyRR/PNrvYLNyjERM' ><i class="fa fa-cart-plus" id='cart-icon' aria-hidden="true"></a></i></li>
            <li class = 'nav-style'><a href='#'>ABOUT US</a></li>
            <li class = 'nav-style'><a href='#'>FUTURE PRODUCTS</a></li>
            <li class = 'nav-style'  id='shop'><a href='C:\Users\User\OneDrive\Desktop\MyFold2\Anul 3 Info\Tehnologii Web\FloraShop\FloraShop.html'>SHOP </a></li>
            <li class='nav-style'><a href='C:\Users\User\OneDrive\Desktop\MyFold2\Anul 3 Info\Tehnologii Web\FloraShop\Home.html'>HOME</a></li>
          </ul>
        </nav>
        
        <div class='main'>
        
          <div id='sidenav'>
            <p style='font-size:25px'>SHOP</p>
            <a href='#' data-name='French'>French</a>
            <a href='#' >Colombian</a>
            <a href='#'>American</a>
            <a href='#'>Java</a>
            <a href='#'>Mocha</a>
            <a href='#'>Blue Mountain</a>
          </div>
          
          <div class='products-col'>
          <h2>OFFERS</h2>
          <div class='flex-grid'>
            <div class="simpleCart_shelfItem col">
          <img src='https://c1.staticflickr.com/4/3927/33987376925_b7ca54ab9a_z.jpg' class='smaller-img img-responsive item_thumb'>
          <h6 class="item_name"> Blue Mountain </h6>
          <span class="item_price">$150</span><br>
          <a class="item_add" href="javascript:;"> Add to Cart </a>
              </div>
            
            <div class="simpleCart_shelfItem col">
          <img src='https://c1.staticflickr.com/4/3939/33987376465_3feff40be8_z.jpg' class='smaller-img img-responsive item_thumb'>
          <h6 class="item_name"> Colombian </h6>
          <span class="item_price">$35</span><br>
          <a class="item_add" href="javascript:;"> Add to Cart </a>
              </div>
            
            <div class="simpleCart_shelfItem col">
          <img src='https://c1.staticflickr.com/4/3947/33987376045_bab0901385_z.jpg' class='smaller-img img-responsive item_thumb'>
          <h6 class="item_name"> Java </h5>
          <span class="item_price">$75</span><br>
          <a class="item_add" href="javascript:;"> Add to Cart </a>
              </div>
           
         <div class="simpleCart_shelfItem col">
          <img src='https://c1.staticflickr.com/3/2923/33175563003_0e1f3027cb_z.jpg' class='smaller-img img-responsive item_thumb'>
          <h6 class="item_name"> Pre-ground </h6>
          <span class="item_price">$15</span><br>
          <a class="item_add" href="javascript:;"> Add to Cart </a>
              </div>
            
            <div class="simpleCart_shelfItem col">
          <img src='https://c1.staticflickr.com/3/2862/33175563343_d749df808e_z.jpg' class='smaller-img img-responsive item_thumb'>
          <h6 class="item_name"> American </h6>
          <span class="item_price">$42</span><br>
          <a class="item_add" href="javascript:;"> Add to Cart </a>
              </div>
            
            <div class="simpleCart_shelfItem col">
          <img src='https://c1.staticflickr.com/3/2829/33175563553_800517b481_z.jpg' class='smaller-img img-responsive item_thumb'>
          <h6 class="item_name"> Mocha </h6>
          <span class="item_price">$30</span><br>
          <a class="item_add" href="javascript:;"> Add to Cart </a>
              </div>
            
            
        </div>
          </div>
        </div>
        </div>
    </body>
</html>
